/**
 * Author: Simon Lindholm
 * Date: 2016-03-22
 * License: CC0
 * Source: hacKIT, NWERC 2015
 * Description: A set (not multiset!) with support for finding the $n^{th}$
 * element, and finding the index of an element.
 * To get a map, change \texttt{null\_type}.
 * Time: O(\log N)
 */
#pragma once

#include <bits/extc++.h> /// keep-include
using namespace __gnu_pbds;

template <class T>
using Tree = tree<T, null_type, less<T>, rb_tree_tag,
    tree_order_statistics_node_update>;

void example() {
	Tree<int> T, T2; T.insert(8);
	auto it = T.insert(10).first;
	assert(it == T.lower_bound(9));
	assert(T.order_of_key(10) == 1);
	assert(T.order_of_key(11) == 2);
	assert(*T.find_by_order(0) == 8);
	T.join(T2); // assuming T < T2 or T > T2, merge T2 into T
}
